import pygame
import  random
pygame.init()

SIZE = WIDTH, HEIGHT = 1000,700

# Screen
SCREEN = pygame.display.set_mode(SIZE)

# R,G,B - Red, Green, Blue
BLACK = 0,0,0
WHITE = 255,255,255
RED = 255,0,0
BLUE = 0,0,255
COLOR = 150, 100, 200

def home():
    img = pygame.image.load("home.jpg")
    img = pygame.transform.scale(img, (WIDTH, HEIGHT))
    main_music = pygame.mixer.Sound("music.mp3")
    main_music.play()
    while True:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    main()

        SCREEN.blit(img, (0,0))

        pygame.display.flip()

def showLives(lifeCount):
    font = pygame.font.SysFont(None, 50)
    text = font.render("Lives : {}".format(lifeCount), True, BLACK)
    SCREEN.blit(text, (5,5))

def showScore(score):
    font = pygame.font.SysFont(None, 50)
    text = font.render("Score : {}".format(score), True, BLUE)
    SCREEN.blit(text, (205,5))

def main():
    SPEED = 2
    move_x = 0

    player_img = pygame.image.load("player.png")
    player_width = player_img.get_width()
    player_height = player_img.get_height()

    player_x = WIDTH // 2 - player_width // 2
    player_y = HEIGHT - player_height - 10

    bullet_radius = 4
    bullet_x = player_x + player_width // 2
    bullet_y = player_y + 4
    bullet_color = RED
    move_bullet = 0

    bullet_sound = pygame.mixer.Sound("sound_1.wav")

    enemy_img = pygame.image.load("enemy.png")
    enemy_width = enemy_img.get_width()
    enemy_height = enemy_img.get_height()

    enemyList = []
    col = 7
    row = 3

    for i in range(1,row + 1):
        for j in range(1,col + 1):
            enemy_x = j * (enemy_width + 5)
            enemy_y = i * (enemy_height + 10)
            enemy_rect = pygame.Rect(enemy_x, enemy_y, enemy_width, enemy_height)
            enemyList.append(enemy_rect)

    random_enemy = random.choice(enemyList)

    clock = pygame.time.Clock()
    FPS = 1000

    lifeCount = 3
    score = 0

    while True:

        SCREEN.fill(WHITE)
        bullet_x = player_x + player_width // 2

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RIGHT:
                    move_x = SPEED
                elif event.key == pygame.K_LEFT:
                    move_x = -SPEED
                elif event.key == pygame.K_SPACE:
                    move_bullet = -8
                    bullet_sound.play()
            else:
                move_x = 0

        for i in range(len(enemyList)):
            SCREEN.blit(enemy_img, (enemyList[i].x, enemyList[i].y))

        pygame.draw.circle(SCREEN, bullet_color, [bullet_x, bullet_y], bullet_radius)
        bullet_rect = pygame.Rect(bullet_x, bullet_y, bullet_radius, bullet_radius)


        SCREEN.blit(player_img, (player_x, player_y))
        player_x += move_x
        bullet_y += move_bullet

        for i in range(len(enemyList)):
            if bullet_rect.colliderect(enemyList[i]):
                del enemyList[i]
                bullet_y = player_y
                move_bullet = 0
                break

        if player_x > WIDTH - 50:
            move_x = -SPEED
        elif player_x < 0:
            move_x = SPEED

        if bullet_y < 0:
            bullet_y = player_y
            move_bullet = 0

        showLives(lifeCount)
        showScore(score)

        # update screen
        pygame.display.flip()
        clock.tick(FPS)

# main()
home()